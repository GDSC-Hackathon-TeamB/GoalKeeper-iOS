//
//  LoginPageViewController.swift
//  GoalKeeper-iOS
//
//  Created by 이지훈 on 1/13/24.
//

import UIKit

class LoginPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()



    }
    


}
